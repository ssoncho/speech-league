# Лига Речи (Frontend)

## Стек
- React + TypeScript

### Библиотеки:
- Axios
- React-Router
- Swiper

## Запуск проекта
1. Скопировать проект в любую папку
2. ```npm i```
3. ```npm run dev```