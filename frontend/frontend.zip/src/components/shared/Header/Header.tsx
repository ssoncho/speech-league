import s from "./Header.module.css";
import { Link } from "react-router";
import { useEffect } from "react";
import { useLocation } from "react-router";
import { Text } from "@gravity-ui/uikit";

type HeaderLink = {
    name: string;
    link: string;
};

const HEADER_LINKS: HeaderLink[] = [
    { name: "КТО МЫ", link: "/" },
    { name: "ПРОЕКТЫ", link: "/" },
    { name: "СООБЩЕСТВА", link: "/login" },
];

const Header = () => {
    const location = useLocation();
    const rootElement = document.getElementById("root");

    useEffect(() => {
        if (
            location.pathname === "/login" ||
            location.pathname === "/register"
        ) {
            rootElement?.classList.add("authPage");
        } else {
            rootElement?.classList.remove("authPage");
        }
    }, [location.pathname, rootElement]);

    return (
        <header className={`header ${s.header}`}>
            <div className={`flex ${s.container}`}>
                <img
                    src="images/logo.webp"
                    alt="Логотип Лиги Речи"
                    className={s.logo}
                />
                <ul className={`flex ${s.header_navlist}`}>
                    {HEADER_LINKS.map((link: HeaderLink) => {
                        return (
                            <li className={s.header_navitem}>
                                <Text variant='header-1'><Link  to={link.link}>{link.name}</Link></Text>
                            </li>
                        );
                    })}
                </ul>
                <select className={s.select} name="city" id="city">
                    <option value="ekb">Екатеринбург</option>
                </select>
            </div>
        </header>
    );
};

export default Header;
