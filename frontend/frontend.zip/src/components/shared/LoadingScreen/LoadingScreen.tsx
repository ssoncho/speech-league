import s from "./LoadingScreen.module.css";
import { Loader } from "@gravity-ui/uikit";

const LoadingScreen = () => {
    return (
        <div className={`flex ${s.wrap}`}>
            <Loader size="l" />
        </div>
    );
};

export default LoadingScreen;
