import s from "./ProfileHeader.module.css";

const ProfileHeader = () => {
    return (
        <header className={`header ${s.header}`}>
            <div className={`flex ${s.container}`}>
                <img
                    src="images/logo.webp"
                    alt="Логотип Лиги Речи"
                    className={s.logo}
                />
            </div>
        </header>
    );
};

export default ProfileHeader;
