import s from "./AboutMe.module.css";

const AboutMe = () => {
    return (
        <section className={s.section}>
            <h2 className={s.title}>Обо мне</h2>
        </section>
    );
};

export default AboutMe;
