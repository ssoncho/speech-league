import s from "./Donations.module.css";
import { Text } from "@gravity-ui/uikit";

const Donations = () => {
    return (
        <section className={`flex section ${s.section}`}>
            <img src="icons/donate.svg" alt="" />
            <div className={s.content}>
                <Text variant="display-3">Не забывайте иногда донатить нам!</Text>
                <br />
                <Text variant="display-3">
                    Любая сумма от <span className={s.sum}>50₽</span> даст нам
                    возможность улучшать портал и создавать новые крутые
                    бесплатные мероприятия. Спасибо за помощь!
                </Text>
            </div>
        </section>
    );
};

export default Donations;
