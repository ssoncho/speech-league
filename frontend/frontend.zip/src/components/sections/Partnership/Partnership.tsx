import s from "./Partnership.module.css";
import { Text } from "@gravity-ui/uikit";

const Partnership = () => {
    return (
        <section className="section">
            <div className={s.content}>
                <div className={`${s.grid_section} ${s.lt}`}>
                    <div className={`flex ${s.wrap}`}>
                        <Text as="h2" variant="display-2">
                            Делаете крутое бесплатное мероприятие?
                        </Text>
                        <Text variant="body-2">
                            Добро пожаловать! Наш клуб организаторов будет рад
                            принять вас в свои ряды!
                        </Text>
                    </div>
                </div>
                <div className={`${s.grid_section} ${s.rt}`}>
                    <div className={`flex ${s.wrap}`}>
                        <Text as="h2" variant="display-2">
                            У Вас клуб или сообщество? Развиваете гибкий навык?
                        </Text>
                        <Text variant="body-2">
                            Присоединяйтесь к нашему клубу организаторов! Ваши
                            анонсы появятся в календаре Лиги Речи, к Вам придут
                            новые участники. А Вы иногда будете делиться опытом
                            бесплатно.
                        </Text>
                    </div>
                </div>
                <div className={`${s.grid_section} ${s.lb}`}>
                    <div className={`flex ${s.wrap}`}>
                        <Text as="h2" variant="display-2">
                            Не коммерческий проект?Нужны тренеры-волонтёры?
                        </Text>
                        <Text variant="body-2">
                            Найдём Вам активных тренеров-новичков. Договоримся,
                            чтобы помогли бесплатно в обмен на Вашу PR-поддержку
                            нашему проекту.
                        </Text>
                    </div>
                </div>
                <div className={`${s.grid_section} ${s.rb}`}>
                    <div className={`flex ${s.wrap}`}>
                        <Text as="h2" variant="display-2">
                            Вы из бизнеса?Хотите развивать сотрудников?
                        </Text>
                        <Text variant="body-2">
                            Подберём профессионального тренера под Ваши задачи,
                            предложим варианты. У нас десятки тренеров, мы
                            каждого видели в деле, дадим рекомендации.
                        </Text>
                    </div>
                </div>
            </div>
            <Text as="h3" variant="display-3">
                Звоните и начнём сотрудничество: +7 950 550-07-71
            </Text>
        </section>
    );
};

export default Partnership;
