import s from "./PartnerCard.module.css";
import { PartnerCardType } from "@mytypes/types";
import { Text } from "@gravity-ui/uikit";

type PartnerCardProps = {
    partner: PartnerCardType;
};

const PartnerCard: React.FC<PartnerCardProps> = ({ partner }) => {
    const { name, avatar } = partner;
    return (
        <li className={`flex ${s.card}`}>
            <img className={s.avatar} src={avatar} alt="" />
            <Text className={s.name} variant="body-3">{name}</Text>
        </li>
    );
};

export default PartnerCard;
