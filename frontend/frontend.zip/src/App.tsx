import "./App.css";
import { Routes, Route } from "react-router";
import MainLayout from "@layout/MainLayout";
import Login from "@pages/Login/Login";
import Register from "@pages/Register/Register";
import Home from "@pages/Home/Home";
import ProfileLayout from "@layout/ProfileLayout";
import AboutMe from "@sections/AboutMe/AboutMe";

function App() {
    return (
        <>
            <Routes>
                <Route element={<MainLayout />}>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                </Route>
                <Route element={<ProfileLayout />}>
                    <Route path="/profile" element={<AboutMe />}></Route>
                </Route>
            </Routes>
        </>
    );
}

export default App;
