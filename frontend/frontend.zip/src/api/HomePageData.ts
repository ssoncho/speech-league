import axios from "axios";

const apiLink = "https://speech-league.onrender.com/api";

const TOKEN =
  "e347d52973ed1f74b205a863cec73a8efcc589b6f20bf1b4f9870f79ea3dd14a1318d7fcbdfc9a13a66bb204a11a2bb24ba7b935a29b5d53db2c7d6b8dc2ec4328d87bfec9dc43779ac30f9f499106c62f890542f199add6a018b5ce3844cc8b7eb64b0c8c7e9bdac8052960497280295a8ab829363b0aa69e5890c250b2040f";

const getHomePageData = async () => {
  try {
    const response = await axios.get(
      "https://speech-league.onrender.com/api/home-page"
    );
    return response.data.data;
  } catch (error) {
    console.error(error);
  }
};

export { getHomePageData };
